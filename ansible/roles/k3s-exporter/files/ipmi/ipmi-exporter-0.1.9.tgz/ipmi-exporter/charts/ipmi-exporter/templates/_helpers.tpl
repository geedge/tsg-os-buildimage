{{- define "pnnlmiscscripts.ipmi-exporter.server" -}}
{{- if and (hasKey . "section") (hasKey .section "server") .section.server -}}
{{ .section.server }}
{{- else -}}
docker.io
{{- end -}}
{{- end -}}

{{- define "pnnlmiscscripts.ipmi-exporter.prefix" -}}
{{- if and (hasKey . "section") (hasKey .section "prefix") .section.prefix -}}
/{{ .section.prefix }}
{{- end -}}
{{- end -}}

{{- define "pnnlmiscscripts.ipmi-exporter.org" -}}
{{- if and (hasKey . "section") (hasKey .section "org") .section.org -}}
{{ .section.org }}
{{- else -}}
pnnlmiscscripts
{{- end -}}
{{- end -}}

{{- define "pnnlmiscscripts.ipmi-exporter.repo" -}}
{{- if and (hasKey . "section") (hasKey .section "repo") .section.repo -}}
{{ .section.repo }}
{{- else -}}
ipmi-exporter
{{- end -}}
{{- end -}}

{{- define "pnnlmiscscripts.ipmi-exporter.tag" -}}
{{- if and (hasKey . "section") (hasKey .section "tag") .section.tag -}}
{{ .section.tag }}
{{- else -}}
1.2.0-9
{{- end -}}
{{- end -}}

{{- /*
How to use:
  {{ dict "dot" . "section" (index .Values "ipmi-exporter") | include "pnnlmiscscripts.ipmi-exporter.image" }}
*/ -}}
{{- define "pnnlmiscscripts.ipmi-exporter.image" -}}
{{- include "pnnlmiscscripts.ipmi-exporter.server" . -}}{{- include "pnnlmiscscripts.ipmi-exporter.prefix" . -}}/{{- include "pnnlmiscscripts.ipmi-exporter.org" . -}}/{{- include "pnnlmiscscripts.ipmi-exporter.repo" . -}}:{{- include "pnnlmiscscripts.ipmi-exporter.tag" . -}}
{{- end -}}
