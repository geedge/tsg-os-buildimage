# ASTF MODE

## Introduction

[ASTF](https://trex-tgn.cisco.com/trex/doc/trex_astf.html) (Advanced Stateful Traffic Flow) mode in TRex is designed for advanced stateful traffic generation. This mode enables the creation and testing of complex bidirectional traffic flows that simulate real-world application behavior. ASTF mode supports a wide range of protocols and allows for precise control over traffic patterns, making it ideal for performance testing, capacity planning, and stress testing of network devices and applications.

With ASTF mode, users can emulate realistic traffic scenarios, including detailed application-level interactions. This mode is particularly useful for testing scenarios that require accurate simulation of client-server communications, such as web browsing, email, and other transactional services. By providing detailed insights into how applications perform under various conditions, ASTF mode helps optimize network configurations and improve overall application performance.
