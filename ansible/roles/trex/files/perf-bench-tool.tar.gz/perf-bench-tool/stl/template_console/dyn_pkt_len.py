from trex_stl_lib.api import *
import ipaddress
import random
import yaml
import os

# Get PBT path from environment variable
PBT_PATH = os.getenv('PBT_PATH')
if not PBT_PATH:
    print("Error: PBT_PATH environment variable is not set.")
    sys.exit(1)

# Configuration file path
CONFIG_FILE_PATH = f'{PBT_PATH}/conf/stl-conf.yaml'

def load_config(config_file):
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    
    # Validate configuration
    required_keys = ["SRC_IP_RANGES", "DST_IP_RANGES", "SRC_PORT_RANGES", "DST_PORT_RANGES", "PKT_LENGTHS", "PROTOCOL"]
    for key in required_keys:
        if key not in config:
            raise ValueError(f"Missing required config key: {key}")

    # Validate IP ranges
    for ip_range in config["SRC_IP_RANGES"] + config["DST_IP_RANGES"]:
        if not isinstance(ip_range, list) or len(ip_range) != 2:
            raise ValueError(f"Invalid IP range format: {ip_range}")
        ipaddress.IPv4Address(ip_range[0])
        ipaddress.IPv4Address(ip_range[1])

    # Validate port ranges
    for port_range in config["SRC_PORT_RANGES"] + config["DST_PORT_RANGES"]:
        if not isinstance(port_range, list) or len(port_range) != 2:
            raise ValueError(f"Invalid port range format: {port_range}")
        if not (0 <= port_range[0] <= 65535) or not (0 <= port_range[1] <= 65535):
            raise ValueError(f"Invalid port range values: {port_range}")

    # Validate packet lengths
    if not all(isinstance(pkt_len, int) and pkt_len > 0 for pkt_len in config["PKT_LENGTHS"]):
        raise ValueError("Invalid packet length values")

    # Validate protocol
    if config["PROTOCOL"] not in ["UDP", "TCP"]:
        raise ValueError("Invalid protocol value")

    return config

# Load configuration from the configuration file
config = load_config(CONFIG_FILE_PATH)

# Use global variables from the configuration file
SRC_IP_RANGES = config["SRC_IP_RANGES"]
DST_IP_RANGES = config["DST_IP_RANGES"]
SRC_PORT_RANGES = config["SRC_PORT_RANGES"]
DST_PORT_RANGES = config["DST_PORT_RANGES"]
PKT_LENGTHS = config["PKT_LENGTHS"]
PROTOCOL = config["PROTOCOL"]

def ip_to_int(ip):
    return int(ipaddress.IPv4Address(ip))

def create_random_ip(ip_range):
    start_ip, end_ip = ip_range
    return str(ipaddress.IPv4Address(random.randint(int(ipaddress.IPv4Address(start_ip)), int(ipaddress.IPv4Address(end_ip)))))

def create_random_port(port_range):
    start_port, end_port = port_range
    return random.randint(start_port, end_port)

class STLS1(object):
    """ Generates a profile with multiple streams based on SRC_IP_RANGES """

    def __init__(self):
        self.max_pkt_size_l3 = 9 * 1024

    def create_stream(self, src_ip_range, dst_ip_range, src_port_range, dst_port_range, protocol=PROTOCOL, pkt_len=None):
        pkt_len = pkt_len or random.choice(PKT_LENGTHS)

        if protocol == "UDP":
            base_pkt = Ether() / IP() / UDP()
        elif protocol == "TCP":
            base_pkt = Ether() / IP() / TCP()
        else:
            raise ValueError("Unsupported protocol type. Please choose 'TCP' or 'UDP'.")
        
        # Calculate the padding length needed to reach the specified packet length
        total_hdr_len = len(base_pkt)
        pad_len = max(0, pkt_len - total_hdr_len)
        pad = pad_len * b'\x00'
        
        # Create the final packet (with padding)
        pkt = base_pkt / pad
        
        # Create the VM program
        vm = STLScVmRaw([
            STLVmFlowVar(name="src_ip", min_value=ip_to_int(src_ip_range[0]), max_value=ip_to_int(src_ip_range[1]), size=4, op="random"),
            STLVmFlowVar(name="dst_ip", min_value=ip_to_int(dst_ip_range[0]), max_value=ip_to_int(dst_ip_range[1]), size=4, op="random"),
            STLVmFlowVar(name="src_port", min_value=src_port_range[0], max_value=src_port_range[1], size=2, op="random"),
            STLVmFlowVar(name="dst_port", min_value=dst_port_range[0], max_value=dst_port_range[1], size=2, op="random"),
            STLVmWrFlowVar(fv_name="src_ip", pkt_offset="IP.src"),
            STLVmWrFlowVar(fv_name="dst_ip", pkt_offset="IP.dst"),
            STLVmWrFlowVar(fv_name="src_port", pkt_offset="UDP.sport" if protocol == "UDP" else "TCP.sport"),
            STLVmWrFlowVar(fv_name="dst_port", pkt_offset="UDP.dport" if protocol == "UDP" else "TCP.dport"),
            STLVmFixIpv4(offset="IP")
        ])

        pkt = STLPktBuilder(pkt=pkt, vm=vm)

        return STLStream(packet=pkt, mode=STLTXCont())

    def get_streams(self, tunables, **kwargs):
        streams = []
        for i, src_ip_range in enumerate(SRC_IP_RANGES):
            dst_ip_range = DST_IP_RANGES[i % len(DST_IP_RANGES)]
            src_port_range = SRC_PORT_RANGES[i % len(SRC_PORT_RANGES)]
            dst_port_range = DST_PORT_RANGES[i % len(DST_PORT_RANGES)]
            streams.append(
                self.create_stream(src_ip_range, dst_ip_range, src_port_range, dst_port_range)
            )

        # Create chained stream profiles
        for i in range(len(streams)):
            streams[i].next = streams[(i + 1) % len(streams)].name
            streams[i].isg = 10.0 if i == 0 else 0.0  # Set initial delay

        return STLProfile(streams).get_streams()

# Dynamic loading - for trex console or simulator
def register():
    return STLS1()