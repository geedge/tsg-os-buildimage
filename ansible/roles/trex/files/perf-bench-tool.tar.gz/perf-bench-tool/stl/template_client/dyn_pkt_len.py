#!/usr/bin/env python3

from trex_stl_lib.api import *
import ipaddress
import random
import argparse
import sys
import os
import time
import signal

def ip_to_int(ip):
    return int(ipaddress.IPv4Address(ip))

def create_random_ip(ip_range):
    start_ip, end_ip = ip_range
    return str(ipaddress.IPv4Address(random.randint(int(ipaddress.IPv4Address(start_ip)), int(ipaddress.IPv4Address(end_ip)))))

def create_random_port(port_range):
    start_port, end_port = port_range
    return random.randint(start_port, end_port)

class STLS1(object):
    """ Generates a profile with multiple streams based on provided ranges """

    def __init__(self, src_ip_ranges, dst_ip_ranges, src_port_ranges, dst_port_ranges, pkt_lengths, protocol):
        self.max_pkt_size_l3 = 9 * 1024
        self.SRC_IP_RANGES = src_ip_ranges
        self.DST_IP_RANGES = dst_ip_ranges
        self.SRC_PORT_RANGES = src_port_ranges
        self.DST_PORT_RANGES = dst_port_ranges
        self.PKT_LENGTHS = pkt_lengths
        self.PROTOCOL = protocol

    def create_stream(self, src_ip_range, dst_ip_range, src_port_range, dst_port_range, protocol=None, pkt_len=None):
        protocol = protocol or self.PROTOCOL
        pkt_len = pkt_len or random.choice(self.PKT_LENGTHS)

        if protocol == "udp":
            base_pkt = Ether() / IP() / UDP()
        elif protocol == "tcp":
            base_pkt = Ether() / IP() / TCP()
        else:
            raise ValueError("Unsupported protocol type. Please choose 'tcp' or 'udp'.")

        # Calculate the padding length needed to reach the specified packet length
        total_hdr_len = len(base_pkt)
        pad_len = max(0, pkt_len - total_hdr_len)
        pad = pad_len * b'\x00'
        
        # Create the final packet (with padding)
        pkt = base_pkt / pad
        
        # Create the VM program
        vm = STLScVmRaw([
            STLVmFlowVar(name="src_ip", min_value=ip_to_int(src_ip_range[0]), max_value=ip_to_int(src_ip_range[1]), size=4, op="random"),
            STLVmFlowVar(name="dst_ip", min_value=ip_to_int(dst_ip_range[0]), max_value=ip_to_int(dst_ip_range[1]), size=4, op="random"),
            STLVmFlowVar(name="src_port", min_value=src_port_range[0], max_value=src_port_range[1], size=2, op="random"),
            STLVmFlowVar(name="dst_port", min_value=dst_port_range[0], max_value=dst_port_range[1], size=2, op="random"),
            STLVmWrFlowVar(fv_name="src_ip", pkt_offset="IP.src"),
            STLVmWrFlowVar(fv_name="dst_ip", pkt_offset="IP.dst"),
            STLVmWrFlowVar(fv_name="src_port", pkt_offset="UDP.sport" if protocol == "udp" else "TCP.sport"),
            STLVmWrFlowVar(fv_name="dst_port", pkt_offset="UDP.dport" if protocol == "udp" else "TCP.dport"),
            STLVmFixIpv4(offset="IP")
        ])

        pkt = STLPktBuilder(pkt=pkt, vm=vm)

        return STLStream(packet=pkt, mode=STLTXCont())

    def get_streams(self):
        streams = []
        for i, src_ip_range in enumerate(self.SRC_IP_RANGES):
            dst_ip_range = self.DST_IP_RANGES[i % len(self.DST_IP_RANGES)]
            src_port_range = self.SRC_PORT_RANGES[i % len(self.SRC_PORT_RANGES)]
            dst_port_range = self.DST_PORT_RANGES[i % len(self.DST_PORT_RANGES)]
            streams.append(
                self.create_stream(src_ip_range, dst_ip_range, src_port_range, dst_port_range)
            )

        # Create chained stream profiles
        for i in range(len(streams)):
            streams[i].next = streams[(i + 1) % len(streams)].name
            streams[i].isg = 10.0 if i == 0 else 0.0  # Set initial delay

        return STLProfile(streams).get_streams()

# Function to calculate packet loss rate
def calculate_loss_rate(opackets, ipackets):
    if opackets == 0:
        return "N/A"
    loss_rate = ((opackets - ipackets) / opackets) * 100
    loss_rate = max(loss_rate, 0)  # Ensure the loss rate is not negative
    return f"{loss_rate:.2f} %"

# Function to display stats
def display_stats(c, ports):
    start_time = time.time()
    column_width = 20  # Fixed column width

    try:
        while c.is_traffic_active():
            elapsed_time = time.time() - start_time

            stats = c.get_stats(ports=ports)
            global_stats = stats.pop('global', {})
            total_stats = stats.pop('total', {})

            # Function to format values with units
            def format_value(key, value):
                units = {
                    'tx_pps': 'pps',
                    'rx_pps': 'pps',
                    'tx_bps': 'bps',
                    'rx_bps': 'bps',
                    'tx_bps_L1': 'bps',
                    'rx_bps_L1': 'bps',
                    'cpu_util': '%',
                    'rx_util': '%',
                    'tx_util': '%',
                }
                if key in units:
                    if 'pps' in units[key]:
                        if value >= 1e6:
                            return f"{value / 1e6:.2f} M{units[key]}"
                        elif value >= 1e3:
                            return f"{value / 1e3:.2f} k{units[key]}"
                    elif 'bps' in units[key]:
                        if value >= 1e9:
                            return f"{value / 1e9:.2f} G{units[key]}"
                        elif value >= 1e6:
                            return f"{value / 1e6:.2f} M{units[key]}"
                        elif value >= 1e3:
                            return f"{value / 1e3:.2f} k{units[key]}"
                    elif units[key] == '%':
                        return f"{value:.2f} {units[key]}"
                return str(value)  # Ensure the return value is a string

            # Display elapsed time
            print(f"Elapsed time: {elapsed_time:.2f} seconds\n")

            # Display global stats
            print("- Global stats")
            for key, value in global_stats.items():
                print(f"  {key}: {format_value(key, value)}")
            print("")

            # Display per port stats
            port_stats_list = []
            for port in ports:
                port_stats = stats.get(port, {})
                port_stats_list.append(port_stats)

            print("- Per port stats")
            header = "Statistic".ljust(column_width) + "".join([f"Port {port}".ljust(column_width) for port in ports])
            print(header)
            print("=" * len(header))

            for key in port_stats_list[0].keys():
                values = [format_value(key, port_stats.get(key, 'N/A')).ljust(column_width) for port_stats in port_stats_list]
                print(f"{key.ljust(column_width)}" + "".join(values))
            print("")

            # Display total stats
            print("- Total stats")
            for key, value in total_stats.items():
                print(f"  {key}: {format_value(key, value)}")

            # Calculate and display packet loss rate
            opackets = total_stats.get('opackets', 0)
            ipackets = total_stats.get('ipackets', 0)
            loss_rate = calculate_loss_rate(opackets, ipackets)
            print(f"  Packet loss rate: {loss_rate}")
            print("")

            sys.stdout.flush()  # Ensure that all print statements are flushed

            time.sleep(1)  # Update interval

    except KeyboardInterrupt:
        print("\nTraffic interrupted by user")
        c.stop(ports=ports)  # Stop traffic when interrupted

    return stats

# Function to display final stats once
def display_final_stats(c, ports):
    final_stats = c.get_stats(ports=ports)
    global_stats = final_stats.pop('global', {})
    total_stats = final_stats.pop('total', {})

    # Display final stats summary
    print("\nFinal Stats Summary:")
    for port in ports:
        port_stats = final_stats.get(port, {})
        opackets = port_stats.get('opackets', 0)
        ipackets = port_stats.get('ipackets', 0)
        print(f"Port {port}: Sent packets: {opackets}, Received packets: {ipackets}")

    total_opackets = total_stats.get('opackets', 0)
    total_ipackets = total_stats.get('ipackets', 0)
    total_loss_rate = calculate_loss_rate(total_opackets, total_ipackets)
    print(f"Total packet loss rate: {total_loss_rate}\n")

def setParserOptions():
    parser = argparse.ArgumentParser(prog="stl_pcap.py", description="TRex traffic generation script")

    parser.add_argument("--src-ip-ranges", help="Source IP ranges (comma separated list of ranges, e.g., '10.0.0.1-10.0.0.255,192.168.1.1-192.168.1.255')",
                        dest="src_ip_ranges",
                        required=True,
                        type=str)

    parser.add_argument("--dst-ip-ranges", help="Destination IP ranges (comma separated list of ranges, e.g., '10.0.1.1-10.0.1.255,192.168.2.1-192.168.2.255')",
                        dest="dst_ip_ranges",
                        required=True,
                        type=str)

    parser.add_argument("--src-port-ranges", help="Source port ranges (comma separated list of ranges, e.g., '1000-2000,3000-4000')",
                        dest="src_port_ranges",
                        required=True,
                        type=str)

    parser.add_argument("--dst-port-ranges", help="Destination port ranges (comma separated list of ranges, e.g., '1500-2500,3500-4500')",
                        dest="dst_port_ranges",
                        required=True,
                        type=str)

    parser.add_argument("--pkt-lengths", help="Packet lengths (comma separated list of lengths, e.g., '64,128,256')",
                        dest="pkt_lengths",
                        required=True,
                        type=str)

    parser.add_argument("--protocol", help="Protocol (udp or tcp)",
                        dest="protocol",
                        required=True,
                        type=str)

    parser.add_argument("-p", "--ports", help="Ports to inject on (comma separated list)",
                        dest="ports",
                        required=True,
                        type=str)

    parser.add_argument("-d", help="Duration in seconds",
                        dest="duration",
                        default=-1,
                        type=float)

    parser.add_argument("-m", "--multiplier", help=(
                        "Multiplier should be passed in the following format:\n"
                        "[number][<empty> | bps | kbps | mbps | gbps | pps |\n"
                        "kpps | mpps | %% ]. no suffix will provide an absolute\n"
                        "factor and percentage will provide a percentage of the\n"
                        "line rate. examples '-m 10', '-m 10kbps', '-m\n"
                        "10kbpsl1', '-m 10mpps', '-m 23%%' : is 23%% L1\n"
                        "bandwidth '-m 23mbps': is 23mbps in L2 bandwidth\n"
                        "(including FCS+4) '-m 23mbpsl1': is 23mbps in L1\n"
                        "bandwidth"),
                        dest="multiplier",
                        required=True,
                        type=str)

    return parser

def sizeof_fmt(num, suffix='B'):
    for unit in ['','Ki','Mi','Gi','Ti','Pi','Ei','Zi']:
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Yi', suffix)

def start(args):
    parser = setParserOptions()
    options = parser.parse_args(args)

    # Convert comma-separated values to appropriate types
    src_ip_ranges = [r.split('-') for r in options.src_ip_ranges.split(',')]
    dst_ip_ranges = [r.split('-') for r in options.dst_ip_ranges.split(',')]
    src_port_ranges = [list(map(int, r.split('-'))) for r in options.src_port_ranges.split(',')]
    dst_port_ranges = [list(map(int, r.split('-'))) for r in options.dst_port_ranges.split(',')]
    pkt_lengths = list(map(int, options.pkt_lengths.split(',')))
    protocol = options.protocol

    ports = [int(port) for port in options.ports.split(',')]

    c = STLClient()

    def signal_handler(sig, frame):
        print("Stopping traffic...")
        c.stop(ports=ports)
        display_final_stats(c, ports)
        c.release(ports=ports)
        c.disconnect()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    try:
        c.connect()
        c.acquire(ports=ports, force=True)  # Acquire the ports

        profile = STLS1(src_ip_ranges, dst_ip_ranges, src_port_ranges, dst_port_ranges, pkt_lengths, protocol)
        
        streams = profile.get_streams()
        c.add_streams(streams, ports)

        print("Starting traffic")
        c.start(ports=ports, duration=options.duration, force=True, mult=options.multiplier)

        # Display stats while traffic is running
        display_stats(c, ports)
        
        # Wait for traffic to complete
        c.wait_on_traffic(ports=ports)
        print("Traffic completed")

    except STLError as e:
        print(e)
        return

    finally:
        # Fetch final stats before disconnecting
        if c.is_connected():
            display_final_stats(c, ports)
            c.release(ports=ports)
            c.disconnect()

def main():
    start(sys.argv[1:])

# inject traffic
if __name__ == '__main__':
    main()
