# PBT

## Introduction

The Performance Benchmark Tool (PBT) is a comprehensive performance testing tool based on TRex. It is designed to support a wide range of testing scenarios to ensure optimal network performance and reliability. PBT offers the following features:

* Support for Different Packet Sizes: Test with various packet sizes, including 64-byte, 128-byte, 256-byte, 512-byte, and 1024-byte packets, to simulate diverse traffic conditions.
* Support for Different Session Rates (5-tuple): Specify IP address ranges and create a varying number of new sessions to assess the performance of network devices under different loads.
* Support for Packet Rate (Packets Per Second): Control the packet generation rate to evaluate how the network handles different traffic intensities.
* Support for Packet Replay: Replay captured packets to simulate real-world traffic patterns and assess the network’s behavior under actual conditions.
* Comprehensive Test Results: Display detailed performance metrics, including actual testing rates (Gbps, PPS), packet loss rates, and latency (average and maximum).

PBT is an essential tool for network performance benchmarking, helping users optimize their network configurations and improve overall performance by providing accurate and reliable test results.

## User Guide

### Overview

The Performance Benchmark Tool (PBT) provides a robust framework for conducting performance testing using TRex. The tool’s parameters are structured into three levels, and each level supports the --help flag to display available options and usage instructions:

1. First Level: Displays the test cases supported by PBT. Use ./pbt -h to view the available test cases.
2. Second Level: Provides usage details and supported parameters for each specific test case. Use -h after the test case name to view this information.
3. Third Level: Allows passing arguments to the underlying TRex tool using args. This level also supports -h for help.

### Test Case: pkt-replay

The pkt-replay case is designed for packet replay testing. It currently supports pcap files but not pcapng. Follow these steps to use this test case:

1. View Supported Parameters: ./pbt pkt-replay -h
2. Show Available Ports: ./pbt pkt-replay --show-port
3. View Lower-Level Parameters: ./pbt pkt-replay args -h
4. Execute Test Case:

   `./pbt pkt-replay args -f /opt/tsg/trex/v3.02/cap2/https.pcap -p 0,1 -n 0 -i 100 -d 10`

### Test Case: diff-pktlen

The diff-pktlen case is for testing with packets of different lengths. Follow these steps to use this test case:

1. View Supported Parameters: ./pbt diff-pktlen -h
2. Show Available Ports: ./pbt diff-pktlen --show-port
3. View Lower-Level Parameters: ./pbt diff-pktlen args -h
4. Execute Test Case:

   `./pbt diff-pktlen args --src-ip-ranges '10.0.0.1-10.0.0.255,192.168.1.1-192.168.1.255' --dst-ip-ranges '10.0.1.1-10.0.1.255,192.168.2.1-192.168.2.255' --src-port-ranges '1000-2000,3000-4000' --dst-port-ranges '1500-2500,3500-4500' --pkt-lengths '64,128,256' --protocol TCP -p 0,1 -m 10mpps -d 20`

### Test Case: cps

The cps case is for testing connections per second. Follow these steps to use this test case:

1. View Supported Parameters: ./pbt cps -h
2. View Lower-Level Parameters: ./pbt cps args -h
3. Execute Test Case:
   `./pbt cps --src-ip-ranges "192.168.1.1-192.168.1.50,192.168.1.100-192.168.1.150" --dst-ip-ranges "192.168.2.1-192.168.2.50,192.168.2.100-192.168.2.150" --dst-port-ranges "3000-3050,4000-4050" --templates-count 10 --templates-cps 20 --protocol udp args -l 200 -d 20`

### Test Case: stf

The stf case is for running TRex’s STF mode. Follow these steps to use this test case:

1. View Supported Parameters: ./pbt stf -h
2. View Lower-Level Parameters: ./pbt stf args -h
3. Execute Test Case:
   `./pbt stf -f /opt/tsg/perf-bench-tool/stf/ssl-fragment/template.yaml args -m 11 -l 1000 -d 20`

This guide provides a comprehensive overview of how to use the PBT tool for various test cases. Always ensure that you consult the help flags (-h and args -h) for the most up-to-date and detailed information on the parameters and usage of each test case.

### TRex Commonly Used Arguments

In this section, we will provide an overview of the most commonly used arguments for TRex. For a complete list of parameters and detailed descriptions, please refer to the official [TRex documentation](https://trex-tgn.cisco.com/trex/doc/trex_manual.html#_command_line_options).

#### Common Arguments

- **`-m` Rate Multiplier**: Multiplies the basic rate of templates by this number. This allows users to adjust the traffic rate according to their testing needs.
- **`-l` Latency Check**: Runs a latency check in parallel to the test, sending packets at a specified rate per second from each interface. This is useful for measuring network latency under load.
- **`-d` Duration**: Specifies the duration of the test in seconds. The default duration is 3600 seconds (1 hour). Additionally, you can use `--nc` to run the test with no duration limit, allowing for continuous testing until manually stopped.

These arguments help users customize their TRex testing scenarios to accurately simulate real-world network conditions and measure performance metrics effectively. For a comprehensive understanding of all available parameters, please refer to the [TRex manual](https://trex-tgn.cisco.com/trex/doc/trex_manual.html).

### The case eg

1. **Replay Packets from a pcap File** :
   Replay the packets from the file located at **/opt/tsg/trex/v3.02/cap2/https.pcap**. Set the ports to 0 and 1, loop count to forever, inter-packet gap (IPG) to 100 microseconds, and duration to 10 seconds:
   `./pbt pkt-replay args -f /opt/tsg/trex/v3.02/cap2/https.pcap -p 0,1 -n 0 -i 100 -d 10`
2. **Generate TCP Packets with Different Lengths** :
   Generate TCP packets with lengths of 64, 128, and 256 bytes. Define the source and destination IP and port ranges, set the ports to 0 and 1, use a multiplier of 10 million packets per second (mpps), and set the duration to 20 seconds:
   `./pbt diff-pktlen args --src-ip-ranges '10.0.0.1-10.0.0.255,192.168.1.1-192.168.1.255' --dst-ip-ranges '10.0.1.1-10.0.1.255,192.168.2.1-192.168.2.255' --src-port-ranges '1000-2000,3000-4000' --dst-port-ranges '1500-2500,3500-4500' --pkt-lengths '64,128,256' --protocol TCP -p 0,1 -m 10mpps -d 20`
3. **Generate UDP CPS** :
   Generate UDP connections per second (CPS). Define the source and destination IP and port ranges, set the ports to 0 and 1, set the templates count to 10, and each template’s CPS to 20 (resulting in a total CPS of 200). Additionally, set the latency check to 200 per second and the duration to 20 seconds:
   `./pbt cps --src-ip-ranges "192.168.1.1-192.168.1.50,192.168.1.100-192.168.1.150" --dst-ip-ranges "192.168.2.1-192.168.2.50,192.168.2.100-192.168.2.150" --dst-port-ranges "3000-3050,4000-4050" --templates-count 10 --templates-cps 20 --protocol udp args -l 200 -d 20`
4. **Use Template in STF Mode** :
   Use an existing template in STF mode. Set the multiplier, the latency check to 1000 per second, and the duration to 20 seconds:
   `./pbt stf -f /opt/tsg/perf-bench-tool/stf/ssl-fragment/template.yaml args -m 11 -l 1000 -d 20`

## **QA**

**Q: How do I view the TRex log in interactive mode?**

**A:** You can view the TRex log in interactive mode by using the following command:

`tail -f /tmp/trex.log`
