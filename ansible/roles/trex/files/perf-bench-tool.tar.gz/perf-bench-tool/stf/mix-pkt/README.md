# Mix Pkt

## Introduction

This template is designed for mixed packet traffic.

## User Guide

* Command

  * ./pbt stf -f (absolute path to template.yaml) args (trex args)
* Generate traffic at a rate of 1 Gbps.

  * ./pbt stf -f /opt/tsg/perf-bench-tool/stf/mix-pkt/template.yaml args -m 11 -l 1000 -d 20
