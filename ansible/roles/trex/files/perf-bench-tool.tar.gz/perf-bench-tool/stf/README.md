# STF MODE

## Introduction

[STF](https://trex-tgn.cisco.com/trex/doc/trex_manual.html) mode in TRex is specifically designed for stateful traffic generation. This mode allows users to create and test complex traffic patterns that simulate real-world network scenarios. With STF mode, users can generate stateful flows that include various protocols and application behaviors, providing a comprehensive tool for performance testing, troubleshooting, and optimizing network configurations.

## User Guide

* Prepare
  * Before starting the STF test case, you need to prepare the template.yaml file and the corresponding pcap file. For more information on how to write the template.yaml file, please refer to the [Trex website](https://trex-tgn.cisco.com/trex/doc/trex_manual.html#_platform_yaml_cfg_argument) .
* Command
  * ./pbt stf -f (absolute path to template.yaml) args (trex args)
* e.g., generate SSL-fragment traffic at a rate of 1 Gbps.
  * ./pbt stf -f /opt/tsg/perf-bench-tool/stf/ssl-fragment/template.yaml args -m 11 -l 1000 -d 20
