bind_addr = "0.0.0.0"
client_addr = "0.0.0.0"
server = true
node_name = "shaping_sentinel"
bootstrap_expect = 1
ui_config {
  enabled = true
}


