#!/bin/bash

#host_ip

#nacos_server_ip
nacos_server_ip=`echo $NACOS_SERVER_IP`

if [ -n  "$nacos_server_ip" ];then
 sed -i "s/nacos.config.server-addr=.*/nacos.config.server-addr=$nacos_server_ip:8848/g" /opt/tsg/cm/api/config/application-prod.properties
fi

#minio init
m_mb=`mc ls minio|wc -l`

if [ $m_mb -lt 3 ];then

mc mb minio/tsg
mc anonymous  set  public minio/tsg
mc mb minio/proxybucket
mc anonymous  set  public minio/proxybucket
mc mb minio/settings
mc anonymous  set  public minio/settings
mc mb minio/auditlog
mc anonymous  set  public minio/auditlog
mc mb minio/policybackup
mc anonymous  set  public minio/policybackup
mc mb minio/tsginit
mc anonymous  set  public minio/tsginit

mc cp -r /opt/tsg/minio/initFile/* minio/tsg 
mc cp -r /opt/tsg/minio/initFile/* minio/tsginit


while true;do
 sleep 1m
 result_cm_code=`curl  -X GET  -I -m 10 -o /dev/null -s -w %{http_code}  --header "Accept: */*"  "http://127.0.0.1:8080/v1/user/encryptpwd?password=1"`

if [ 200 -eq $result_cm_code ]; then
 
mysql -hcm-mariadb -uroot -p'Bifang&*()' -P3306 tsg-bifang -e "SELECT CONCAT(cfg_name, '=', cfg_value) AS '' FROM t_sys_cfg where cfg_type=1 and cfg_name !='device_tags';" > /opt/tsg/cm/cm.properties

redis-cli -p 7002 -n 0 SET SYNCALLCONFIG 1

curl -X GET --header "Accept: */*"   --header "Authorization: aa2bdec5518ad131f71944b13ce5c298&1&"  "http://127.0.0.1:8080/v1/policy/object/canalData"

 break
fi

done

while true;do
 sleep 1m
 result_code=`curl -I -m 10 -o /dev/null -s -w %{http_code} http://$nacos_server_ip:8848/nacos/v1/console/server/state`

 if [ 200 -eq $result_code ]; then
     echo "Nacos service is normal >>> Success"
     curl --data-urlencode content="`cat /opt/tsg/cm/cm.properties`"  --request POST "http://$nacos_server_ip:8848/nacos/v1/cs/configs?username=nacos&password=nacos&tenant=prod&group=cm&dataId=cm-api&appName=cm&type=properties"
      break
   else
       echo "Nacos service is abnormal >>> Fail"

 fi
done
fi
