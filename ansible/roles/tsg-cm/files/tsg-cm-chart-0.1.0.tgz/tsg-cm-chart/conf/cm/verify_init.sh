#!/bin/bash
host_ip=`echo $HOST_IP`

if [ -n  "$HOST_IP" ];then
 sed -i "s/consul_host=.*/consul_host=$HOST_IP/g" /opt/tsg/swarmkv-sentinel/conf/swarmkv_sentinel.conf
 sed -i "s/cluster_announce_host=.*/cluster_announce_host=$HOST_IP/g" /opt/tsg/swarmkv-sentinel/conf/swarmkv_sentinel.conf
fi

#重启 swarmkv-sentinel
supervisorctl stop swarmkv-sentinel
supervisorctl start swarmkv-sentinel