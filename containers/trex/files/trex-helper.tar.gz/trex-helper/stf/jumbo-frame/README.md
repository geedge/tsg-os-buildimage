# Jumbo Frame

## Introduction

This template is designed for jumbo frame traffic.

## User Guide

* Command

  * ./trex-helper stf -f (absolute path to template.yaml) args (trex args)
* Generate traffic at a rate of 1 Gbps.

  * ./trex-helper stf -f /opt/tsg/trex-helper/stf/jumbo-frame/len-*/template.yaml args -m 11 -l 1000 -d 20
