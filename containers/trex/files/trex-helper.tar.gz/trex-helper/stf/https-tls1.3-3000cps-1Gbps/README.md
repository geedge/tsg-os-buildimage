# Https-tls1.3

## Introduction

This template is designed for HTTPS TLS 1.3 traffic models at 3000 Cps/Gbps.

## User Guide

* Command

  * ./trex-helper stf -f (absolute path to template.yaml) args (trex args)
* Generate traffic at a rate of 1 Gbps.

  * ./trex-helper stf -f /opt/tsg/trex-helper/stf/https-tls1.3-3000cps-1Gbps/template.yaml args -m 45 -l 1000 -d 20
