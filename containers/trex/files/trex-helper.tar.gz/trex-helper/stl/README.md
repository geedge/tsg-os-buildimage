# STL MODE

## Introduction

STL mode in TRex is designed for stateless traffic generation. This mode allows users to create and test various traffic patterns without maintaining any connection state. With STL mode, users can generate high-speed traffic flows using multiple protocols and packet types, providing a versatile tool for performance benchmarking, capacity planning, and stress testing network devices. This mode is ideal for scenarios where the focus is on packet-level performance and throughput rather than connection-oriented traffic behavior.

### **Console and Client API**

TRex provides a powerful console interface and a comprehensive client API for interacting with STL mode. The console interface allows users to easily configure and control traffic generation through a command-line interface, offering quick and flexible access to all STL mode features.

The client API, available in Python, provides programmatic access to TRex’s STL functionality, enabling users to automate traffic generation tasks, integrate with other systems, and develop custom testing scripts. With the client API, users can define complex traffic profiles, control traffic streams, and collect detailed performance metrics, making it an essential tool for advanced network testing and automation.

## Note

The TREX HELPER app does not support console mode.
