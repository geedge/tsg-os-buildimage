# The script is modified from “automation/trex_control_plane/interactive/trex/examples/stl/stl_pcap_remote.py”
#!/usr/bin/env python3

import stl_path
from trex.stl.api import *
import argparse
import sys
import os
import time
import signal

# Function to calculate packet loss rate
def calculate_loss_rate(opackets, ipackets):
    if opackets == 0:
        return "N/A"
    loss_rate = ((opackets - ipackets) / opackets) * 100
    loss_rate = max(loss_rate, 0)  # Ensure the loss rate is not negative
    return f"{loss_rate:.2f} %"

def inject_pcap(c, pcap_file, ports, loop_count, ipg_usec, duration, speedup):
    pcap_file = os.path.abspath(pcap_file)

    c.reset(ports=ports)
    c.push_pcap(pcap_file, ports=ports, ipg_usec=ipg_usec, speedup=speedup, count=loop_count, duration=duration,force=True)
    return c

def display_stats(c, ports):
    start_time = time.time()
    column_width = 20  # Fixed column width

    try:
        while c.is_traffic_active():
            elapsed_time = time.time() - start_time

            stats = c.get_stats()
            global_stats = stats.pop('global', {})
            total_stats = stats.pop('total', {})

            # Function to format values with units
            def format_value(key, value):
                units = {
                    'tx_pps': 'pps',
                    'rx_pps': 'pps',
                    'tx_bps': 'bps',
                    'rx_bps': 'bps',
                    'tx_bps_L1': 'bps',
                    'rx_bps_L1': 'bps',
                    'cpu_util': '%',
                    'rx_util': '%',
                    'tx_util': '%',
                }
                if key in units:
                    if 'pps' in units[key]:
                        if value >= 1e6:
                            return f"{value / 1e6:.2f} M{units[key]}"
                        elif value >= 1e3:
                            return f"{value / 1e3:.2f} k{units[key]}"
                    elif 'bps' in units[key]:
                        if value >= 1e9:
                            return f"{value / 1e9:.2f} G{units[key]}"
                        elif value >= 1e6:
                            return f"{value / 1e6:.2f} M{units[key]}"
                        elif value >= 1e3:
                            return f"{value / 1e3:.2f} k{units[key]}"
                    elif units[key] == '%':
                        return f"{value:.2f} {units[key]}"
                return str(value)  # Ensure the return value is a string

            # Display elapsed time
            print(f"Elapsed time: {elapsed_time:.2f} seconds\n")

            # Display global stats
            print("- Global stats")
            for key, value in global_stats.items():
                print(f"  {key}: {format_value(key, value)}")
            print("")

            # Display per port stats
            port_stats_list = []
            for port in ports:
                port_stats = stats.get(port, {})
                port_stats_list.append(port_stats)

            print("- Per port stats")
            header = "Statistic".ljust(column_width) + "".join([f"Port {port}".ljust(column_width) for port in ports])
            print(header)
            print("=" * len(header))

            for key in port_stats_list[0].keys():
                values = [format_value(key, port_stats.get(key, 'N/A')).ljust(column_width) for port_stats in port_stats_list]
                print(f"{key.ljust(column_width)}" + "".join(values))
            print("")

            # Display total stats
            print("- Total stats")
            for key, value in total_stats.items():
                print(f"  {key}: {format_value(key, value)}")

            # Calculate and display packet loss rate
            opackets = total_stats.get('opackets', 0)
            ipackets = total_stats.get('ipackets', 0)
            loss_rate = calculate_loss_rate(opackets, ipackets)
            print(f"  Packet loss rate: {loss_rate}")
            print("")

            time.sleep(1)  # Update interval

            if not c.is_traffic_active():
                break

    except KeyboardInterrupt:
        print("\nTraffic interrupted by user")
        c.stop(ports=ports)  # Stop traffic when interrupted

    return stats

# Function to display final stats once
def display_final_stats(c, ports):
    final_stats = c.get_stats()
    global_stats = final_stats.pop('global', {})
    total_stats = final_stats.pop('total', {})

    # Display final stats summary
    print("\nFinal Stats Summary:")
    for port in ports:
        port_stats = final_stats.get(port, {})
        opackets = port_stats.get('opackets', 0)
        ipackets = port_stats.get('ipackets', 0)
        print(f"Port {port}: Sent packets: {opackets}, Received packets: {ipackets}")

    total_opackets = total_stats.get('opackets', 0)
    total_ipackets = total_stats.get('ipackets', 0)
    total_loss_rate = calculate_loss_rate(total_opackets, total_ipackets)
    print(f"Total packet loss rate: {total_loss_rate}\n")

def setParserOptions():
    parser = argparse.ArgumentParser(prog="stl_pcap.py")

    parser.add_argument("-f", "--file", help="Pcap file to replay",
                        dest="pcap",
                        required=True,
                        type=str)

    parser.add_argument("-p", "--ports", help="Ports to replay on (comma separated list)",
                        dest="ports",
                        required=True,
                        type=str)

    parser.add_argument("-l", "--loop", help="Loop through the capture file X times. [default is 1, 0 means forever]",
                        dest="loop_count",
                        default=1,
                        type=int)

    parser.add_argument("-i","--ipg", help="Inter-packet gap in usec.",
                        dest="ipg",
                        default=None,
                        type=float)

    parser.add_argument("-s","--speedup", help="A factor to adjust IPG. effectively IPG = IPG / speedup",
                        dest="speedup",
                        default=1.0,
                        type=float)
    
    parser.add_argument("-d","--duration", help="Duration in seconds",
                        dest="duration",
                        default=-1,
                        type=float)

    return parser

def sizeof_fmt(num, suffix='B'):
    for unit in ['','Ki','Mi','Gi','Ti','Pi','Ei','Zi']:
        if abs(num) < 1024.0:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Yi', suffix)

def read_txt_file(filename):
    with open(filename) as f:
        lines = f.readlines()

    caps = []
    for raw in lines:
        raw = raw.rstrip()
        if raw[0] == '#':
            continue
        ext = os.path.splitext(raw)[1]
        if ext not in ['.cap', '.pcap', '.erf']:
            # skip unknown format
            continue

        caps.append(raw)

    return caps

def start(args):
    parser = setParserOptions()
    options = parser.parse_args(args)

    # Convert comma-separated ports to list of integers
    ports = [int(port) for port in options.ports.split(',')]

    ext = os.path.splitext(options.pcap)[1]
    if ext == '.txt':
        caps = read_txt_file(options.pcap)
    elif ext in ['.cap', '.pcap']:
        caps = [options.pcap]
    else:
        print("unknown file extension for file {0}".format(options.pcap))
        return

    c = STLClient()

    def signal_handler(sig, frame):
        print("Stopping traffic...")
        c.stop(ports=ports)
        display_final_stats(c, ports)
        c.disconnect()
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    try:
        c.connect()
        for i, cap in enumerate(caps, start=1):
            before = time.time()
            print("{:} CAP {:} @ {:} - ".format(i, cap, sizeof_fmt(os.path.getsize(cap))), end="")
            inject_pcap(c, cap, ports, options.loop_count, options.ipg, options.duration, options.speedup)
            print("took {:.2f} seconds".format(time.time() - before))

        display_stats(c, ports)

    except STLError as e:
        print(e)
        return

    finally:
        # Fetch final stats before disconnecting
        if c.is_connected():
            display_final_stats(c, ports)
            c.disconnect()

def main():
    start(sys.argv[1:])

# replay pcap
if __name__ == '__main__':
    main()
