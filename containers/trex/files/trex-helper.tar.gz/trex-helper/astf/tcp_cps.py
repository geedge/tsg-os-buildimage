#!/usr/bin/env python3

from trex.astf.api import *
import yaml
import os
import sys

# Get TREX HELPER path from environment variable
TREX_HELPER_PATH = os.getenv('TREX_HELPER_PATH')
if not TREX_HELPER_PATH:
    print("Error: TREX_HELPER_PATH environment variable is not set.")
    sys.exit(1)

# Configuration file path
CONFIG_FILE_PATH = f'{TREX_HELPER_PATH}/conf/astf-conf.yaml'

# HTTP request and response templates
http_req = b'GET /3384 HTTP/1.1\r\nHost: 22.0.0.3\r\nConnection: Keep-Alive\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)\r\nAccept: */*\r\nAccept-Language: en-us\r\nAccept-Encoding: gzip, deflate, compress\r\n\r\n'
http_response_template = 'HTTP/1.1 200 OK\r\nServer: Microsoft-IIS/6.0\r\nContent-Type: text/html\r\nContent-Length: 4000\r\n\r\n<html><pre>{0}</pre></html>'

class Prof1():
    def __init__(self):
        self.load_config()
        self.check_config()

    def load_config(self):
        if not os.path.isfile(CONFIG_FILE_PATH):
            print(f"Error: Configuration file {CONFIG_FILE_PATH} does not exist.")
            sys.exit(1)
        with open(CONFIG_FILE_PATH, 'r') as file:
            self.config = yaml.safe_load(file)

    def check_config(self):
        # Calculate templates_count as the total number of dst ports
        self.templates_count = sum([int(r[1]) - int(r[0]) + 1 for r in self.config['DST_PORT_RANGES']])

    def create_ip_gen(self, ip_ranges):
        ip_gens = []
        for ip_range in ip_ranges:
            ip_gen = ASTFIPGenDist(ip_range=ip_range, distribution="rand")
            ip_gens.append(ip_gen)
        return ip_gens

    def create_profile(self):
        # client commands
        prog_c = ASTFProgram()
        prog_c.send(http_req)
        prog_c.recv(len(http_response_template))

        prog_s = ASTFProgram()
        prog_s.recv(len(http_req))
        prog_s.send(http_response_template)

        # ip generator
        ip_gen_c_list = self.create_ip_gen(self.config['SRC_IP_RANGES'])
        ip_gen_s_list = self.create_ip_gen(self.config['DST_IP_RANGES'])

        templates = []
        CPS = self.config['CPS']

        # Convert CPS to cps if necessary
        if isinstance(CPS, str):
            if CPS.endswith('kcps'):
                CPS = float(CPS[:-4]) * 1e3
            elif CPS.endswith('mcps'):
                CPS = float(CPS[:-4]) * 1e6
            elif CPS.endswith('cps'):
                CPS = float(CPS[:-3])
            else:
                raise ValueError(f"Invalid CPS format: {CPS}")
        else:
            CPS = float(CPS)

        # Calculate templates_cps
        templates_cps = CPS / self.templates_count
        if templates_cps < 0.5:
            templates_cps = 0.5
            self.templates_count = int(CPS / templates_cps)

        ip_gen_index = 0

        for dst_port_range in self.config['DST_PORT_RANGES']:
            for dst_port in range(int(dst_port_range[0]), int(dst_port_range[1]) + 1):
                if len(templates) >= self.templates_count:
                    break
                # cycle through the IP ranges
                ip_gen_c = ip_gen_c_list[ip_gen_index % len(ip_gen_c_list)]
                ip_gen_s = ip_gen_s_list[ip_gen_index % len(ip_gen_s_list)]
                ip_gen_index += 1

                ip_gen = ASTFIPGen(glob=ASTFIPGenGlobal(ip_offset="1.0.0.0"),
                                   dist_client=ip_gen_c,
                                   dist_server=ip_gen_s)

                # template
                temp_c = ASTFTCPClientTemplate(program=prog_c, ip_gen=ip_gen, cps=templates_cps, port=dst_port)
                temp_s = ASTFTCPServerTemplate(program=prog_s, assoc=ASTFAssociationRule(port=dst_port))  # using default association
                template = ASTFTemplate(client_template=temp_c, server_template=temp_s)
                templates.append(template)
            if len(templates) >= self.templates_count:
                break

        # Print templates count and CPS per template
        print(f"Total Templates Count: {self.templates_count}")
        print(f"CPS per Template: {templates_cps:.2f}")

        # profile
        profile = ASTFProfile(default_ip_gen=ip_gen, templates=templates)
        return profile

    def get_profile(self, tunables, **kwargs):
        return self.create_profile()

def register():
    return Prof1()
